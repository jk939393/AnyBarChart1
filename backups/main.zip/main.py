import json

import quart
import quart_cors
from pptx.util import Inches
from quart import Quart, request, Response, send_file
from pptx import Presentation
from pptx.util import Inches
import io
import logging

app = quart_cors.cors(quart.Quart(__name__), allow_origin="https://chat.openai.com")

# Keep track of todo's. Does not persist if Python session is restarted.
_TODOS = {}

@app.post("/build_ppt")
async def build_powerpoint():
    try:
        request_data = await request.get_json(force=True)
        slides_data = request_data.get("slides", [])
        prs = Presentation()

        slide_info = []

        for i, slide_data in enumerate(slides_data):
            slide_layout = prs.slide_layouts[1]
            slide = prs.slides.add_slide(slide_layout)
            title = slide.shapes.title
            content = slide.placeholders[1]
            title.text = slide_data.get("title", "Default Title")
            content.text = slide_data.get("content", "Default Content")

            # Collect slide information
            slide_info.append({
                "slide_number": i + 1,
                "title": title.text,
                "content": content.text
            })

        return quart.jsonify({"slides": slide_info}), 200
    except Exception as e:
        logging.error(f"An error occurred: {e}")
        return quart.Response(response='Internal Server Error', status=500)

@app.get("/logo.png")
async def plugin_logo():
    filename = 'logo.png'
    return await quart.send_file(filename, mimetype='image/png')

@app.get("/.well-known/ai-plugin.json")
async def plugin_manifest():
    host = request.headers['Host']
    with open("./.well-known/ai-plugin.json") as f:
        text = f.read()
        return quart.Response(text, mimetype="text/json")

@app.get("/openapi.yaml")
async def openapi_spec():
    host = request.headers['Host']
    with open("openapi.yaml") as f:
        text = f.read()
        return quart.Response(text, mimetype="text/yaml")

def main():
    app.run(debug=True, host="0.0.0.0", port=5003)

if __name__ == "__main__":
    main()
